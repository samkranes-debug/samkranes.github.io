const products = [
  {id:1,name:"Essential Oversized Tee",price:59,category:"clothing",image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80"},
  {id:2,name:"Heavyweight Hoodie",price:119,category:"clothing",image:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=80"},
  {id:3,name:"Utility Cargo Pants",price:109,category:"clothing",image:"https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=900&q=80"},
  {id:4,name:"Signature Cap",price:45,category:"accessories",image:"https://images.unsplash.com/photo-1521369909029-2afed882baee?auto=format&fit=crop&w=900&q=80"},
  {id:5,name:"Leather Card Wallet",price:69,category:"accessories",image:"https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=900&q=80"},
  {id:6,name:"Minimal Belt",price:79,category:"accessories",image:"https://images.unsplash.com/photo-1624222247344-550fb60583dc?auto=format&fit=crop&w=900&q=80"}
];

let cart = JSON.parse(localStorage.getItem("kranCart") || "[]");

function money(value){ return "$" + value.toFixed(2); }

function renderProducts(category="all"){
  const box=document.getElementById("products");
  const list=category==="all"?products:products.filter(p=>p.category===category);
  box.innerHTML=list.map(p=>`
    <article class="product-card">
      <img class="product-image" src="${p.image}" alt="${p.name}">
      <div class="product-info">
        <div class="category">${p.category}</div>
        <h3>${p.name}</h3>
        <div class="price">${money(p.price)}</div>
        <button class="add-button" onclick="addToCart(${p.id})">Add to cart</button>
      </div>
    </article>`).join("");
}

function addToCart(id){
  const existing=cart.find(item=>item.id===id);
  if(existing) existing.qty++;
  else cart.push({id,qty:1});
  saveCart();
  openCart();
}

function removeFromCart(id){
  cart=cart.filter(item=>item.id!==id);
  saveCart();
}

function saveCart(){
  localStorage.setItem("kranCart",JSON.stringify(cart));
  renderCart();
}

function renderCart(){
  const box=document.getElementById("cartItems");
  const count=cart.reduce((sum,item)=>sum+item.qty,0);
  document.getElementById("cartCount").textContent=count;
  if(!cart.length){
    box.innerHTML='<div class="cart-empty">Your cart is empty.</div>';
  } else {
    box.innerHTML=cart.map(item=>{
      const p=products.find(x=>x.id===item.id);
      return `<div class="cart-item">
        <img src="${p.image}" alt="${p.name}">
        <div><h4>${p.name}</h4><p>${item.qty} × ${money(p.price)}</p></div>
        <button class="remove" onclick="removeFromCart(${p.id})">Remove</button>
      </div>`;
    }).join("");
  }
  const total=cart.reduce((sum,item)=>{
    const p=products.find(x=>x.id===item.id);
    return sum+p.price*item.qty;
  },0);
  document.getElementById("cartTotal").textContent=money(total);
}

function toggleCart(){
  document.getElementById("cartPanel").classList.toggle("open");
  document.getElementById("overlay").classList.toggle("show");
}
function openCart(){
  document.getElementById("cartPanel").classList.add("open");
  document.getElementById("overlay").classList.add("show");
}
function openCheckout(){
  if(!cart.length){alert("Add a product to your cart first.");return;}
  document.getElementById("checkoutModal").classList.add("show");
}
function closeCheckout(){document.getElementById("checkoutModal").classList.remove("show");}

document.querySelectorAll(".filter").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    renderProducts(btn.dataset.category);
  });
});

document.getElementById("checkoutForm").addEventListener("submit",e=>{
  e.preventDefault();
  document.getElementById("orderMessage").textContent="Demo order placed! No real payment was taken.";
  cart=[];
  saveCart();
});

renderProducts();
renderCart();
